// src/app/services/database.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { User } from '../interfaces/user.interface';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  private dbPath = 'assets/db.json';
  private usersSubject = new BehaviorSubject<User[]>([]);
  users$ = this.usersSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadInitialData();
  }

  private loadInitialData(): void {
    this.http.get<any>(this.dbPath).subscribe({
      next: (data) => this.usersSubject.next(data.users),
      error: (err) => console.error('Error loading DB:', err)
    });
  }


  
  updateUser(updatedUser: User): Observable<any> {
    return this.http.get<any>(this.dbPath).pipe(
      tap((db) => {
        const index = db.users.findIndex((u: User) => u.id === updatedUser.id);
        if (index !== -1) {
          db.users[index] = updatedUser;
          this.usersSubject.next(db.users);
          // En un entorno real, aquí harías un PUT al servidor
          // Por ahora simulamos la actualización local
          console.log('User updated (simulated):', updatedUser);
        }
      })
    );


    
  }

  // Método para simular persistencia hasta que tengas backend
  private updateLocalDB(updatedUser: User): void {
    const currentUsers = this.usersSubject.value;
    const index = currentUsers.findIndex(u => u.id === updatedUser.id);
    if (index !== -1) {
      currentUsers[index] = updatedUser;
      this.usersSubject.next(currentUsers);
    }
  }
}