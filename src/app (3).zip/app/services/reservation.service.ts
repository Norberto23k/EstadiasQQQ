import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ReservationService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getAllReservations(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservations`);
  }

  createReservation(reservationData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/reservations`, reservationData);
  }

  approveReservation(reservationId: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/reservations/${reservationId}/approve`, {});
  }

  rejectReservation(reservationId: string, reason: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/reservations/${reservationId}/reject`, { reason });
  }

  getReservationsByUser(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservations/user/${userId}`);
  }

  getPendingReservations(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservations?status=Pendiente`);
  }
}