import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../interfaces/user.interface';
import { ToastController } from '@ionic/angular/standalone';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private http = inject(HttpClient);
  private toastCtrl = inject(ToastController);
  private apiUrl = environment.apiUrl;

  getAdmins(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/users/admins`).pipe(
      catchError(async err => {
        await this.showToast('Error al obtener administradores', 'danger');
        throw err;
      })
    );
  }

  updateAdmin(admin: User): Observable<User> {
  return this.http.put<User>(`${this.apiUrl}/admins/${admin.id}`, admin);
  // Adjust the endpoint according to your API
}

promoteToAdmin(user: User): Observable<User> {
  return this.http.put<User>(`${this.apiUrl}/users/${user.id}/promote`, {});
}

  demoteAdmin(userId: string): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/users/${userId}/demote`, {}).pipe(
      catchError(async err => {
        await this.showToast('Error al degradar administrador', 'danger');
        throw err;
      })
    );
  }

  createUser(user: Omit<User, 'id'>): Observable<User> {
  return this.http.post<User>(`${this.apiUrl}/users`, user).pipe(
    catchError(async err => {
      await this.showToast('Error creating user', 'danger');
      throw err;
    })
  );
}

  private async showToast(message: string, color: string = 'success'): Promise<void> {
    const toast = await this.toastCtrl.create({
      message,
      duration: 3000,
      position: 'bottom',
      color
    });
    await toast.present();
  }
}