import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Material, Prestamo } from 'src/app/models/material.model';

@Injectable({ providedIn: 'root' })
export class MaterialService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getAllMaterials(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/materials`);
  }

  getMaterialById(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/materials/${id}`);
  }

  createMaterial(material: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/materials`, material);
  }

getActiveLoans(): Observable<any[]> {  // Consider creating a Loan interface
  return this.http.get<any[]>(`${this.apiUrl}/loans/active`);
}

  updateMaterial(id: string, material: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/materials/${id}`, material);
  }

  deleteMaterial(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/materials/${id}`);
  }

  getMaterialByQR(code: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/materials/qr/${code}`);
  }

  getAvailableMaterials(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/materials`).pipe(
      map(materials => materials.filter(m => m.status === 'Disponible'))
    );
  }

  getCategorias(): Observable<string[]> {
  return this.http.get<string[]>(`${this.apiUrl}/materiales/categorias`).pipe(
    catchError(error => {
      console.error('Error fetching categories:', error);
      return of(['Proyectores', 'Computadoras', 'Cámaras', 'Accesorios']); // Default categories
    })
  );
}

  getBorrowedMaterials(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/materials`).pipe(
      map(materials => materials.filter(m => m.status === 'Ocupado'))
    );
  }

  returnMaterial(materialId: string): Observable<Material> {
    return this.http.patch<Material>(`${this.apiUrl}/${materialId}/devolver`, {
      estado: 'Disponible',
      fechaDevolucion: new Date().toISOString()
    });
  }

  // Función adicional que podrías necesitar
  updateLoanStatus(loanId: string, status: 'completado' | 'retrasado'): Observable<Prestamo> {
    return this.http.patch<Prestamo>(`${this.apiUrl}/prestamos/${loanId}`, {
      estado: status,
      fechaDevolucion: status === 'completado' ? new Date().toISOString() : undefined
    });
  }

  
}