const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const app = express();
dotenv.config();

// Middleware
app.use(cors());
app.use(express.json()); // Reemplaza body-parser
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/users', require('./routes/user.routes'));
app.use('/api/materials', require('./routes/material.route'));
app.use('/api/loans', require('./routes/loans.route'));
app.use('/api/reservations', require('./routes/reservations.routes'));
app.use('/api/notifications', require('./routes/notifications.routes'));

// Conexión a MongoDB Atlas
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('✅ Conectado a MongoDB Atlas');
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`🚀 Servidor en puerto ${PORT}`));
})
.catch(err => console.error('❌ Error al conectar MongoDB:', err));
