const express = require('express');
const router = express.Router();
const materialsController = require('../controllers/materials.controller');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');

router.get('/', materialsController.getAllMaterials);
router.get('/:id', materialsController.getMaterialById);
router.get('/qr/:code', materialsController.getMaterialByQR);

// Rutas protegidas para admin
router.post('/', authMiddleware, adminMiddleware, materialsController.createMaterial);
router.put('/:id', authMiddleware, adminMiddleware, materialsController.updateMaterial);
router.delete('/:id', authMiddleware, adminMiddleware, materialsController.deleteMaterial);

module.exports = router;