const express = require('express');
const router = express.Router();
const loansController = require('../controllers/loans.controller');
const authMiddleware = require('../middleware/auth');

router.get('/', authMiddleware, loansController.getAllLoans);
router.post('/', authMiddleware, loansController.createLoan);
router.put('/:id/return', authMiddleware, loansController.returnLoan);
router.get('/user/:userId', authMiddleware, loansController.getLoansByUser);

module.exports = router;