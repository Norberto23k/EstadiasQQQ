const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const authMiddleware = require('../middleware/auth');
const { check } = require('express-validator');

router.post('/register', [
  check('email').isEmail().normalizeEmail(),
  check('password').isLength({ min: 6 }),
  check('name').not().isEmpty().trim()
], authController.register);

router.post('/login', [
  check('email').isEmail().normalizeEmail(),
  check('password').exists()
], authController.login);

router.get('/me', 
  authMiddleware, 
  authController.getMe
);

module.exports = router;